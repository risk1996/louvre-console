#include<stdio.h>
#include<time.h>
#include<string.h>
#include<windows.h>

struct book{
	char name[100], auth[50], genre[30], pub[50];
	short year, stock;
	float price;
};

struct filter{
	int active[7];
	char name[100], auth[50], genre[30], pub[50];
	short yeartop, yearbot, stocktop, stockbot;
	float pricetop, pricebot;
};

struct cartitem{
	int index, amount;
};

struct book booklist[1000];
struct filter filterlist;
struct cartitem cart[100];
int bookamount=0, showbook[1000]={0}, showbookamount=0, page=0, maxpage=0, cartamount=0, sortby=80;
char color[10], pp[50]="mode con: cols=130 lines=00";
static int maxitemperpage=25;

void filterbooks();
void changewindowsize();

void loaddata(){
	FILE *pfile;
	int ctr;
	pfile=fopen("booklist.txt", "r");
	for(ctr=0; 1; ctr++){
		if(fscanf(pfile, "%[^|]|%[^|]|%[^|]|%[^|]|%hd|%hd|%f\n", &booklist[ctr].name, &booklist[ctr].auth, &booklist[ctr].genre, &booklist[ctr].pub, &booklist[ctr].year, &booklist[ctr].stock, &booklist[ctr].price)==EOF)break;
		bookamount++;
	}
	fclose(pfile);
	maxpage=(bookamount-1)/maxitemperpage;
	filterbooks();
}

void loadoption(){
	FILE *pfile;
	int ctr;
	pfile=fopen("option.txt", "r");
	fscanf(pfile, "%[^\n]\n", &color);
	fscanf(pfile, "%d", &maxitemperpage);
	changewindowsize();
	fclose(pfile);
}

void savedata(){
	FILE *pfile;
	int ctr;
	pfile=fopen("booklist.txt", "w");
	for(ctr=0; ctr<bookamount; ctr++){
		fprintf(pfile, "%s|%s|%s|%s|%hd|%hd|%.2f\n", booklist[ctr].name, booklist[ctr].auth, booklist[ctr].genre, booklist[ctr].pub, booklist[ctr].year, booklist[ctr].stock, booklist[ctr].price);
	}
	fclose(pfile);
}

void saveoption(){
	FILE *pfile;
	int ctr;
	pfile=fopen("option.txt", "w");
	fprintf(pfile, "%s\n", color);
	fprintf(pfile, "%d\n", maxitemperpage);
	fclose(pfile);
}

void drawheader(){
	printf("\n");
	printf("\t\t\t\t  ░░░ ░ ░ ░░░\n");
	printf("\t\t\t\t   ░  ░░░ ░░ \n");
	printf("\t\t\t\t   ░  ░ ░ ░░░\n");
	printf("\t\t\t\t▓▓    ▓▓▓▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓▓▓  ▓▓▓▓▓ ▒▒  ▒▒▒ ▒▒▒ ▒ ▒ ▒▒▒ ▒▒▒ ▒▒▒ ▒▒  ▒▒▒\n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓  ▓ ▓▓    ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒    ▒  ▒ ▒ ▒ ▒ ▒  \n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓▓▓  ▓▓▓▓▓ ▒▒  ▒ ▒ ▒ ▒ ▒▒  ▒▒▒  ▒  ▒ ▒ ▒▒  ▒▒▒\n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓    ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒   ▒  ▒  ▒ ▒ ▒ ▒ ▒  \n");
	printf("\t\t\t\t▓▓▓▓▓ ▓▓▓▓▓ ▓▓▓▓▓  ▓▓▓  ▓▓  ▓ ▓▓▓▓▓ ▒▒  ▒▒▒ ▒▒▒ ▒ ▒ ▒▒▒  ▒  ▒▒▒ ▒ ▒ ▒▒▒\n");
	printf("\t\t\t\t\t\tVersion 0.9 Beta (Last updated 9 May 2016)\n");
}

void drawheaders(){
	printf("\n");
	printf("\t\t    The\n");
	printf("\t\t LOUVRE Bookstore   v 0.9a\n");
	printf("\n");
}

char lower(char x){return (x>='A'&&x<='Z')?x+32:x;}
void swap(int *i, int *j){int k=*j;*j=*i;*i=k;}

int issubstring(char main[], char sub[]){
	int mainlen=strlen(main), sublen=strlen(sub), match=0, ctr1, ctr2;
	for(ctr1=0; ctr1<=mainlen-sublen; ctr1++){
		for(ctr2=0; ctr2<sublen; ctr2++){
			if(lower(main[ctr1+ctr2])!=lower(sub[ctr2]))break;
		}
		if(ctr2==sublen)return 1;
	}
	return 0;
}

int checkqualify(struct book test){
	int ctr1, ctr2;
	if(filterlist.active[0]&&!issubstring(test.name, filterlist.name))return 0;
	if(filterlist.active[1]&&!issubstring(test.auth, filterlist.auth))return 0;
	if(filterlist.active[2]&&!issubstring(test.genre, filterlist.genre))return 0;
	if(filterlist.active[3]&&!issubstring(test.pub, filterlist.pub))return 0;
	if(filterlist.active[4]&&(test.year<filterlist.yearbot||test.year>filterlist.yeartop))return 0;
	if(filterlist.active[5]&&(test.stock<filterlist.stockbot||test.stock>filterlist.stocktop))return 0;
	if(filterlist.active[6]&&(test.price<filterlist.pricebot||test.price>filterlist.pricetop))return 0;
	return 1;
}

void filterbooks(){
	int ctr;
	showbookamount=0;
	for(ctr=0; ctr<bookamount; ctr++){
		if(checkqualify(booklist[ctr]))showbook[showbookamount++]=ctr;
	}
	maxpage=(showbookamount-1)/maxitemperpage;
}

void sortbooks(){
	int ctr1, ctr2;
	if(sortby/10==1){
		for(ctr1=0; ctr1<showbookamount-1; ctr1++){
			for(ctr2=ctr1+1; ctr2<showbookamount; ctr2++){
				if(sortby%10==0&&strcmp(booklist[showbook[ctr1]].name, booklist[showbook[ctr2]].name)>0){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
				else if(sortby%10==1&&strcmp(booklist[showbook[ctr1]].name, booklist[showbook[ctr2]].name)<0){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
			}
		}
	}
	else if(sortby/10==2){
		for(ctr1=0; ctr1<showbookamount-1; ctr1++){
			for(ctr2=ctr1+1; ctr2<showbookamount; ctr2++){
				if(sortby%10==0&&strcmp(booklist[showbook[ctr1]].auth, booklist[showbook[ctr2]].auth)>0){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
				else if(sortby%10==1&&strcmp(booklist[showbook[ctr1]].auth, booklist[showbook[ctr2]].auth)<0){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
			}
		}
	}
	else if(sortby/10==3){
		for(ctr1=0; ctr1<showbookamount-1; ctr1++){
			for(ctr2=ctr1+1; ctr2<showbookamount; ctr2++){
				if(sortby%10==0&&strcmp(booklist[showbook[ctr1]].genre, booklist[showbook[ctr2]].genre)>0){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
				else if(sortby%10==1&&strcmp(booklist[showbook[ctr1]].genre, booklist[showbook[ctr2]].genre)<0){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
			}
		}
	}
	else if(sortby/10==4){
		for(ctr1=0; ctr1<showbookamount-1; ctr1++){
			for(ctr2=ctr1+1; ctr2<showbookamount; ctr2++){
				if(sortby%10==0&&strcmp(booklist[showbook[ctr1]].pub, booklist[showbook[ctr2]].pub)>0){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
				else if(sortby%10==1&&strcmp(booklist[showbook[ctr1]].pub, booklist[showbook[ctr2]].pub)<0){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
			}
		}
	}
	else if(sortby/10==5){
		for(ctr1=0; ctr1<showbookamount-1; ctr1++){
			for(ctr2=ctr1+1; ctr2<showbookamount; ctr2++){
				if(sortby%10==0&&booklist[showbook[ctr1]].year>booklist[showbook[ctr2]].year){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
				else if(sortby%10==1&&booklist[showbook[ctr1]].year<booklist[showbook[ctr2]].year){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
			}
		}
	}
	else if(sortby/10==6){
		for(ctr1=0; ctr1<showbookamount-1; ctr1++){
			for(ctr2=ctr1+1; ctr2<showbookamount; ctr2++){
				if(sortby%10==0&&booklist[showbook[ctr1]].stock>booklist[showbook[ctr2]].stock){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
				else if(sortby%10==1&&booklist[showbook[ctr1]].stock<booklist[showbook[ctr2]].stock){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
			}
		}
	}
	else if(sortby/10==7){
		for(ctr1=0; ctr1<showbookamount-1; ctr1++){
			for(ctr2=ctr1+1; ctr2<showbookamount; ctr2++){
				if(sortby%10==0&&booklist[showbook[ctr1]].price>booklist[showbook[ctr2]].price){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
				else if(sortby%10==1&&booklist[showbook[ctr1]].price<booklist[showbook[ctr2]].price){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
			}
		}
	}
	else if(sortby/10==8){
		for(ctr1=0; ctr1<showbookamount-1; ctr1++){
			for(ctr2=ctr1+1; ctr2<showbookamount; ctr2++){
				if(sortby%10==0&&showbook[ctr1]>showbook[ctr2]){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
				else if(sortby%10==1&&showbook[ctr1]<showbook[ctr2]){
					swap(&showbook[ctr1], &showbook[ctr2]);
				}
			}
		}
	}
}

void changewindowsize(){
	int lines=maxitemperpage+25;
	pp[25]=pp[26]='0';
	pp[25]+=lines/10;
	pp[26]+=lines%10;
}

void printinvoice(){
	FILE *pfile;
	int ctr;
	float total;
	char invoicename[100];
	time_t now=time(0);
	struct tm timeinfo;
	timeinfo=*localtime(&now);
	strftime(invoicename, sizeof(invoicename), "invoice_%Y%m%d_%H%M%S.txt", &timeinfo);
	pfile=fopen(invoicename, "w");
	fprintf(pfile, "+------------------------------------------+\n");
	fprintf(pfile, "|           The Louvre Bookstore           |\n");
	fprintf(pfile, "+------------------------------------------+\n");
	for(ctr=0; ctr<cartamount; ctr++){
		fprintf(pfile, "| %-40s |\n", booklist[cart[ctr].index].name);
		fprintf(pfile, "|   %7d x $%8.2f      = $%10.2f |\n", cart[ctr].amount, booklist[cart[ctr].index].price, (float)cart[ctr].amount*booklist[cart[ctr].index].price);
		total+=(float)cart[ctr].amount*booklist[cart[ctr].index].price;
	}
	fprintf(pfile, "+------------------------------------------+\n");
	fprintf(pfile, "|  Total                       $%10.2f |\n", total);
	fprintf(pfile, "|  Tax                         $%10.2f |\n", total*.1);
	fprintf(pfile, "+------------------------------------------+\n");
	fprintf(pfile, "|  GRAND TOTAL                 $%10.2f |\n", total*1.1);
	fprintf(pfile, "+------------------------------------------+\n");
	fprintf(pfile, "|            === Thank  You ===            |\n", total);
	fprintf(pfile, "+------------------------------------------+\n");
	fclose(pfile);
}

void drawcontent(){
	int ctr, i;
	int filteram=0, disp=0;
	printf("    Filters: ");
	if(filterlist.active[0]){printf("Name (%s)", filterlist.name);filteram++;}
	if(filterlist.active[1]){printf("%sAuthor (%s)", filteram?", ":"", filterlist.auth);filteram++;}
	if(filterlist.active[2]){printf("%sGenre (%s)", filteram?", ":"", filterlist.genre);filteram++;}
	if(filterlist.active[3]){printf("%sPublisher (%s)", filteram?", ":"", filterlist.pub);filteram++;}
	if(filterlist.active[4]){printf("%sPublished Year (%hd-%hd)", filteram?", ":"", filterlist.yearbot, filterlist.yeartop);filteram++;}
	if(filterlist.active[5]){printf("%sStock (%hd-%hd)", filteram?", ":"", filterlist.stockbot, filterlist.stocktop);filteram++;}
	if(filterlist.active[6]){printf("%sPrice ($ %.2f-$ %.2f)", filteram?", ":"", filterlist.pricebot, filterlist.pricetop);filteram++;}
	if(filteram==0)printf("None");
	printf("\n");
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	printf("  | BID |            Book Name            |        Author        |    Genre    |     Publisher     | Year | Stock |   Price   |\n");
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	for(ctr=page*maxitemperpage; ctr<showbookamount&&ctr<(page+1)*maxitemperpage; ctr++){
		i=showbook[ctr];
		printf("  | %03d | %-31s | %-20s | %-11s | %-17s | %-4d |  %-4d | $%8.2f |\n", showbook[ctr]+1, booklist[i].name, booklist[i].auth, booklist[i].genre, booklist[i].pub, booklist[i].year, booklist[i].stock, booklist[i].price);
		disp++;
	}
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	char sortstr[20], adstr[5];
	if(sortby/10==1)strcpy(sortstr, "Name");
	else if(sortby/10==2)strcpy(sortstr, "Author");
	else if(sortby/10==3)strcpy(sortstr, "Genre");
	else if(sortby/10==4)strcpy(sortstr, "Publisher");
	else if(sortby/10==5)strcpy(sortstr, "Year");
	else if(sortby/10==6)strcpy(sortstr, "Stock");
	else if(sortby/10==7)strcpy(sortstr, "Price");
	else if(sortby/10==8)strcpy(sortstr, "Boook ID");
	if(sortby%10==0)strcpy(adstr, "▲");
	else strcpy(adstr, "▼");
	printf("    Sort by: %-10s (%s)\t\t\t\t  [ %2d / %2d ]\t\t\t  Showing %4d out of %4d item(s).\n", sortstr, adstr, page+1, maxpage+1, disp, bookamount);
}

void drawmenu(){
	printf("\n");
	printf("\t\tSelect an operation   :\n");
	printf("\t\t\t<. Go to previous page");
	printf("\t\t\t\t>. Go to next page\n");
	printf("\t\t\t1. Make a purchase");
	printf("\t\t\t\t2. Add a book entry\n");
	printf("\t\t\t3. Select and edit an entry");
	printf("\t\t\t4. Sort books\n");
	printf("\t\t\t5. Add or remove filter");
	printf("\t\t\t\t6. Options\n");
	printf("\t\t\t0. Exit and save changes");
	printf("\t\t\t-. Exit and remove changes\n");
	printf("\t\tOperation             : ");
}

void op1(){
	system("mode con: cols=65 lines=30");
	cartamount=0;
	int ctr, index, amount;
	char add='y', com;
	float total=0;
	while(1){
		system("cls");
		drawheaders();
		printf("\t  Cart (%d)\n", cartamount);
		for(ctr=0; ctr<cartamount; ctr++){
			printf("\t%s\n", booklist[cart[ctr].index].name);
			printf("\t%7d x $%8.2f\t\t= $%10.2f\n", cart[ctr].amount, booklist[cart[ctr].index].price, (float)cart[ctr].amount*booklist[cart[ctr].index].price);
		}
		if(cartamount==0)printf("\t(EMPTY)\n");
		else{
			printf("\t______________________________________________+\n");
			printf("\t  TOTAL                           $%10.2f\n", total);
		}
		printf("\n");
		if(lower(add)!='y')break;
		printf("\tAdd a book to cart    : "); scanf("%d", &index); getchar(); index--;
		if(index<0||index>bookamount)continue;
		printf("\tSelected book name    : %s\n", booklist[index].name);
		printf("\tSelected book price   : $%8.2f\n", booklist[index].price);
		printf("\tSelected book stock   : %d\n", booklist[index].stock);
		printf("\tAmount                : ");  scanf("%d", &amount); getchar();
		if(amount<=0||amount>booklist[index].stock)continue;
		struct cartitem newcartitem;
		newcartitem.index=index;
		newcartitem.amount=amount;
		cart[cartamount++]=newcartitem;
		total+=(float)amount*booklist[index].price;
		printf("\tAdd another book (Y/N)? "); scanf("%c", &add); getchar();
	}
	printf("\tCommit purchase  (Y/N)? "); scanf("%c", &com); getchar();
	if(lower(com)=='y'){
		for(ctr=0; ctr<cartamount; ctr++)booklist[cart[ctr].index].stock-=cart[ctr].amount;
		char prt;
		printf("\tPrint Invoice    (Y/N)? "); scanf("%c", &prt); getchar();
		if(lower(prt)=='y')printinvoice();
	}
}

void op2(){
	system("mode con: cols=65 lines=17");
	struct book newbook;
	char save, another='Y';
	while(lower(another)=='y'){
		system("cls");
		drawheaders();
		printf("\tAdd a book entry      :\n");
		printf("\tBook name             : ");scanf("%[^\n]", &newbook.name);getchar();
		printf("\tBook author           : ");scanf("%[^\n]", &newbook.auth);getchar();
		printf("\tBook genre            : ");scanf("%[^\n]", &newbook.genre);getchar();
		printf("\tBook publisher        : ");scanf("%[^\n]", &newbook.pub);getchar();
		printf("\tBook published year   : ");scanf("%hd", &newbook.year); getchar();
		printf("\tBook stock            : ");scanf("%hd", &newbook.stock); getchar();
		printf("\tBook price            : ");scanf("%f", &newbook.price); getchar();
		printf("\tAre you sure you want to save the book (Y/N)? ");scanf("%c", &save); getchar();
		if(lower(save)=='y')booklist[bookamount++]=newbook;
		printf("\tDo you want to add another book        (Y/N)? ");scanf("%c", &another); getchar();
	}
}

void op3(){
	while(1){
		system("cls");
		system("mode con: cols=65 lines=17");
		drawheaders();
		int sel, op;
		printf("\t\t(Select book no. 0 to cancel)\n");
		printf("\tSelect book number    : "); scanf("%d", &sel); getchar();
		if(!sel)return;
		else sel--;
		if(sel<0||sel>bookamount){
			printf("\tInvalid book number.");
			getchar();
			continue;
		}
		system("cls");
		drawheaders();
		char ed='n', com='n';
		printf("\tName           : %s\n", booklist[sel].name);
		printf("\tAuthor         : %s\n", booklist[sel].auth);
		printf("\tGenre          : %s\n", booklist[sel].genre);
		printf("\tPublisher      : %s\n", booklist[sel].pub);
		printf("\tPublished Year : %d\n", booklist[sel].year);
		printf("\tStock          : %d\n", booklist[sel].stock);
		printf("\tPrice          : $ %.2f\n", booklist[sel].price);
		printf("\n\tAre you sure you want to edit this book (Y/N)? "); scanf("%c", &ed);
		if(lower(ed)=='y'){
			system("cls");
			system("mode con: cols=65 lines=25");
			drawheaders();
			printf("\tName           : %s\n", booklist[sel].name);
			printf("\tAuthor         : %s\n", booklist[sel].auth);
			printf("\tGenre          : %s\n", booklist[sel].genre);
			printf("\tPublisher      : %s\n", booklist[sel].pub);
			printf("\tPublished Year : %d\n", booklist[sel].year);
			printf("\tStock          : %d\n", booklist[sel].stock);
			printf("\tPrice          : $ %.2f\n", booklist[sel].price);
			printf("\n");
			printf("\t1. Edit name\n");
			printf("\t2. Edit author\n");
			printf("\t3. Edit genre\n");
			printf("\t4. Edit publisher\n");
			printf("\t5. Edit year\n");
			printf("\t6. Edit stock\n");
			printf("\t7. Edit price\n");
			printf("\t0. Cancel\n");
			printf("\tOperation             : "); scanf("%d", &op); getchar();
			if(!op)continue;
			else if(op>=1&&op<=4){
				char change[100];
				if(op==1)printf("\tChange name to        : ");
				else if(op==2)printf("\tChange author to      : ");
				else if(op==3)printf("\tChange genre to       : ");
				else if(op==4)printf("\tChange publisher to   : ");
				scanf("%[^\n]", &change); getchar();
				printf("\tCommit changes (Y/N)? "); scanf("%c", &com); getchar();
				if(lower(com)=='y'){
					if(op==1)strcpy(booklist[sel].name, change);
					else if(op==2)strcpy(booklist[sel].auth, change);
					else if(op==3)strcpy(booklist[sel].genre, change);
					else if(op==4)strcpy(booklist[sel].pub, change);
				}
			}
			else if(op==5||op==6){
				int change;
				if(op==5)printf("\tChange year to        : ");
				else printf("\tChange stock to       : ");
				scanf("%d", &change); getchar();
				printf("\tCommit changes (Y/N)? "); scanf("%c", &com); getchar();
				if(lower(com)=='y'){
					if(op==5)booklist[sel].year=change;
					else booklist[sel].stock=change;
				}
			}
			else if(op==7){
				float change;
				printf("\tChange price to       : ");
				scanf("%f", &change); getchar();
				printf("\tCommit changes (Y/N)? "); scanf("%c", &com); getchar();
				if(lower(com)=='y')booklist[sel].price=change;
			}
		}
	}
}

void op4(){
	system("cls");
	system("mode con: cols=65 lines=17");
	drawheaders();
	int op, ctr1, ctr2;
	printf("\tSort                  :\n");
	printf("\t1. Sort by name\n");
	printf("\t2. Sort by author\n");
	printf("\t3. Sort by genre\n");
	printf("\t4. Sort by publisher\n");
	printf("\t5. Sort by published year\n");
	printf("\t6. Sort by stock\n");
	printf("\t7. Sort by price\n");
	printf("\t8. Sort by ID\n");
	printf("\t0. cancel\n");
	printf("\tOperation             : ");
	scanf("%d", &op); getchar();
	if(!op)return;
	char ad;
	printf("\tAscending or descending (A/D)? ");
	scanf("%c", &ad); getchar();
	sortby=op*10+(ad=='d'?1:0);
}

void op5(){
	system("cls");
	system("mode con: cols=65 lines=17");
	drawheaders();
	int op, ctr;
	printf("\tFilters               :\n");
	printf("\t\t1. Turn %s name filter\n", filterlist.active[0]?"off":"on");
	printf("\t\t2. Turn %s author filter\n", filterlist.active[1]?"off":"on");
	printf("\t\t3. Turn %s genre filter\n", filterlist.active[2]?"off":"on");
	printf("\t\t4. Turn %s publisher filter\n", filterlist.active[3]?"off":"on");
	printf("\t\t5. Turn %s published year filter\n", filterlist.active[4]?"off":"on");
	printf("\t\t6. Turn %s stock filter\n", filterlist.active[5]?"off":"on");
	printf("\t\t7. Turn %s price filter\n", filterlist.active[6]?"off":"on");
	printf("\t\t8. Clear all filter off\n");
	printf("\t\t0. Cancel\n");
	printf("\tOperation             : ");
	scanf("%d", &op); getchar();
	if(!op)return;
	else if(op==8){for(ctr=0; ctr<7; ctr++)filterlist.active[ctr]=0;}
	else{
		filterlist.active[op-1]=!filterlist.active[op-1];
		if(filterlist.active[op-1]){
			if(op==1){
				printf("\tName Filter           : ");
				scanf("%[^\n]", &filterlist.name);getchar();
			}
			else if(op==2){
				printf("\tAuthor Filter         : ");
				scanf("%[^\n]", &filterlist.auth);getchar();
			}
			else if(op==3){
				printf("\tGenre Filter          : ");
				scanf("%[^\n]", &filterlist.genre);getchar();
			}
			else if(op==4){
				printf("\tPublisher Filter      : ");
				scanf("%[^\n]", &filterlist.pub);getchar();
			}
			else if(op==5){
				printf("\tYear Start Filter     : ");scanf("%hd", &filterlist.yearbot);
				printf("\tYear End   Filter     : ");scanf("%hd", &filterlist.yeartop);
				if(filterlist.yearbot<0)filterlist.yearbot*=-1;
				if(filterlist.yeartop<0)filterlist.yeartop*=-1;
				if(filterlist.yeartop<filterlist.yearbot){
					filterlist.yeartop+=filterlist.yearbot;
					filterlist.yearbot=filterlist.yeartop-filterlist.yearbot;
					filterlist.yeartop=filterlist.yeartop-filterlist.yearbot;
				}
			}
			else if(op==6){
				printf("\tStock Start Filter    : ");scanf("%hd", &filterlist.stockbot);
				printf("\tStock End   Filter    : ");scanf("%hd", &filterlist.stocktop);
				if(filterlist.stockbot<0)filterlist.stockbot*=-1;
				if(filterlist.stocktop<0)filterlist.stocktop*=-1;
				if(filterlist.stocktop<filterlist.stockbot){
					filterlist.stocktop+=filterlist.stockbot;
					filterlist.stockbot=filterlist.stocktop-filterlist.stockbot;
					filterlist.stocktop=filterlist.stocktop-filterlist.stockbot;
				}
			}
			else if(op==7){
				printf("\tPrice Start Filter    : ");scanf("%f", &filterlist.pricebot);
				printf("\tPrice End   Filter    : ");scanf("%f", &filterlist.pricetop);
				if(filterlist.pricebot<0)filterlist.pricebot*=-1;
				if(filterlist.pricetop<0)filterlist.pricetop*=-1;
				if(filterlist.pricetop<filterlist.pricebot){
					filterlist.pricetop+=filterlist.pricebot;
					filterlist.pricebot=filterlist.pricetop-filterlist.pricebot;
					filterlist.pricetop=filterlist.pricetop-filterlist.pricebot;
				}
			}
		}
	}
}

void op6(){
	system("cls");
	system("mode con: cols=65 lines=17");
	drawheaders();
	int op;
	printf("\tOptions               :\n");
	printf("\t\t1. Change background color\n");
	printf("\t\t2. Change text color\n");
	printf("\t\t3. Change maximum item per page\n");
	printf("\t\t0. Cancel\n");
	printf("\tOperation               : "); scanf("%d", &op);
	if(!op)return;
	else if(op==1||op==2){
		system("cls");
		drawheaders();
		if(op==1)printf("\tChange background color :\n");
		else printf("\tChange text color       :\n");
		printf("\t\t0. Black");printf("\t8. Gray\n");
		printf("\t\t1. Blue");printf("\t\t9. Light Blue\n");
		printf("\t\t2. Green");printf("\tA. Light Green\n");
		printf("\t\t3. Aqua");printf("\t\tB. Light Aqua\n");
		printf("\t\t4. Red");printf("\t\tC. Light Red\n");
		printf("\t\t5. Purple");printf("\tD. Light Purple\n");
		printf("\t\t6. Yellow");printf("\tE. Light Yellow\n");
		printf("\t\t7. White");printf("\tF. Bright White\n");
		char col[5];
		printf("\tOperation               : "); scanf("%s", &col);getchar();
		col[0]=lower(col[0]);
		if(op==1){
			if(col[0]==color[7]){printf("\tBackground color cannot be the same as text color,\n\treturn to main menu.\n");getchar();}
			else if(col[0]>='0'&&col[0]<='9'||col[0]>='a'&&col[0]<='f')color[6]=col[0];
			else{printf("\tInvalid color, return to main menu.\n");getchar();}
		}
		else{
			if(col[0]==color[6]){printf("\tBackground color cannot be the same as text color,\n\treturn to main menu.\n");getchar();}
			else if(col[0]>='0'&&col[0]<='9'||col[0]>='a'&&col[0]<='f')color[7]=col[0];
			else{printf("\tInvalid color, return to main menu.\n");getchar();}
		}
	}
	else if(op==3){
		system("cls");
		drawheaders();
		int max;
		printf("\tCurrently showing %d item per page.\n", maxitemperpage);
		printf("\tChange maximum item per page to : "); scanf("%d", &max);
		if(max<0){printf("\tMaximum item per page cannot be negative,\n\treturn to main menu.\n");getchar();}
		else if(max>=10&&max<=30){maxitemperpage=max;changewindowsize();}
		else if(max<10){printf("\tMaximum item per page cannot be below 10,\n\treturn to main menu.\n");getchar();}
		else{printf("\tMaximum item per page cannot exceed 30,\n\treturn to main menu.\n");getchar();}
	}
}

int main(){
	system("chcp 65001");
	system("title \"The Louvre Bookstore\"");
	char inputoperation[10];
	loadoption();
	loaddata();
	while(1){
		system(pp); system("cls"); system(color);
		drawheader(); drawcontent(); drawmenu();
		scanf("%s", &inputoperation);getchar();
		if(inputoperation[0]=='0')break;
		else if(inputoperation[0]=='-')return 0;
		else if(inputoperation[0]=='<')page--;
		else if(inputoperation[0]=='>')page++;
		else if(inputoperation[0]=='1')op1();
		else if(inputoperation[0]=='2')op2();
		else if(inputoperation[0]=='3')op3();
		else if(inputoperation[0]=='4')op4();
		else if(inputoperation[0]=='5')op5();
		else if(inputoperation[0]=='6')op6();
		if(page<0)page=maxpage;
		if(page>maxpage)page=0;
		filterbooks();
		sortbooks();
		if(inputoperation[0]!='<'&&inputoperation[0]!='>')page=0;
	}
	saveoption();
	savedata();
}