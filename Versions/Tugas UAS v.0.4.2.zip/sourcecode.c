#include<stdio.h>
#include<string.h>
#include<windows.h>

struct book{
	char name[100], auth[50], genre[30], pub[50];
	short year, stock;
	float price;
};

struct filter{
	int active[7];
	char name[100], auth[50], genre[30], pub[50];
	short yeartop, yearbot, stocktop, stockbot;
	float pricetop, pricebot;
};

struct book booklist[1000];
struct filter filterlist;
int bookamount=0, showbook[1000]={0}, showbookamount=0, page=0, maxpage=0;
static int maxitemperpage=25;

void filterbooks();

void loaddata(){
	FILE *pfile;
	int ctr;
	pfile=fopen("booklist.txt", "r");
	for(ctr=0; 1; ctr++){
		if(fscanf(pfile, "%[^|]|%[^|]|%[^|]|%[^|]|%hd|%hd|%f\n", &booklist[ctr].name, &booklist[ctr].auth, &booklist[ctr].genre, &booklist[ctr].pub, &booklist[ctr].year, &booklist[ctr].stock, &booklist[ctr].price)==EOF)break;
		bookamount++;
	}
	fclose(pfile);
	maxpage=(bookamount-1)/maxitemperpage;
	filterbooks();
}

void savedata(){
	FILE *pfile;
	int ctr;
	pfile=fopen("booklist.txt", "w");
	for(ctr=0; ctr<bookamount; ctr++){
		fprintf(pfile, "%s|%s|%s|%s|%hd|%hd|%.2f\n", booklist[ctr].name, booklist[ctr].auth, booklist[ctr].genre, booklist[ctr].pub, booklist[ctr].year, booklist[ctr].stock, booklist[ctr].price);
	}
	fclose(pfile);
}

void drawheader(){
	printf("\n");
	printf("\t\t\t\t  ░░░ ░ ░ ░░░\n");
	printf("\t\t\t\t   ░  ░░░ ░░ \n");
	printf("\t\t\t\t   ░  ░ ░ ░░░\n");
	printf("\t\t\t\t▓▓    ▓▓▓▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓▓▓  ▓▓▓▓▓ ▒▒  ▒▒▒ ▒▒▒ ▒ ▒ ▒▒▒ ▒▒▒ ▒▒▒ ▒▒  ▒▒▒\n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓  ▓ ▓▓    ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒    ▒  ▒ ▒ ▒ ▒ ▒  \n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓▓▓  ▓▓▓▓▓ ▒▒  ▒ ▒ ▒ ▒ ▒▒  ▒▒▒  ▒  ▒ ▒ ▒▒  ▒▒▒\n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓    ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒   ▒  ▒  ▒ ▒ ▒ ▒ ▒  \n");
	printf("\t\t\t\t▓▓▓▓▓ ▓▓▓▓▓ ▓▓▓▓▓  ▓▓▓  ▓▓  ▓ ▓▓▓▓▓ ▒▒  ▒▒▒ ▒▒▒ ▒ ▒ ▒▒▒  ▒  ▒▒▒ ▒ ▒ ▒▒▒\n");
	printf("\t\t\t\t\t\tVersion 0.4.2 Alpha (Last updated 3 May 2016)\n");
}

char lower(char x){return (x>='A'&&x<='Z')?x+32:x;}

int issubstring(char main[], char sub[]){
	int mainlen=strlen(main), sublen=strlen(sub), match=0, ctr1, ctr2;
	for(ctr1=0; ctr1<=mainlen-sublen; ctr1++){
		for(ctr2=0; ctr2<sublen; ctr2++){
			if(lower(main[ctr1+ctr2])!=lower(sub[ctr2]))break;
		}
		if(ctr2==sublen)return 1;
	}
	return 0;
}

int checkqualify(struct book test){
	int ctr1, ctr2;
	if(filterlist.active[0]&&!issubstring(test.name, filterlist.name))return 0;
	if(filterlist.active[1]&&!issubstring(test.auth, filterlist.auth))return 0;
	if(filterlist.active[2]&&!issubstring(test.genre, filterlist.genre))return 0;
	if(filterlist.active[3]&&!issubstring(test.pub, filterlist.pub))return 0;
	if(filterlist.active[4]&&(test.year<filterlist.yearbot||test.year>filterlist.yeartop))return 0;
	if(filterlist.active[5]&&(test.stock<filterlist.stockbot||test.stock>filterlist.stocktop))return 0;
	if(filterlist.active[6]&&(test.price<filterlist.pricebot||test.price>filterlist.pricetop))return 0;
	return 1;
}

void filterbooks(){
	int ctr;
	showbookamount=0;
	for(ctr=0; ctr<bookamount; ctr++){
		if(checkqualify(booklist[ctr]))showbook[showbookamount++]=ctr;
	}
}

void drawcontent(){
	int ctr, i;
	int filteram=0, disp=0;
	printf("\tActivated Filter: ");
	if(filterlist.active[0]){printf("Name (%s)", filterlist.name);filteram++;}
	if(filterlist.active[1]){printf("%sAuthor (%s)", filteram?", ":"", filterlist.auth);filteram++;}
	if(filterlist.active[2]){printf("%sGenre (%s)", filteram?", ":"", filterlist.genre);filteram++;}
	if(filterlist.active[3]){printf("%sPublisher (%s)", filteram?", ":"", filterlist.pub);filteram++;}
	if(filterlist.active[4]){printf("%sPublished Year (%hd-%hd)", filteram?", ":"", filterlist.yearbot, filterlist.yeartop);filteram++;}
	if(filterlist.active[5]){printf("%sStock (%hd-%hd)", filteram?", ":"", filterlist.stockbot, filterlist.stocktop);filteram++;}
	if(filterlist.active[6]){printf("%sPrice ($ %.2f-$ %.2f)", filteram?", ":"", filterlist.pricebot, filterlist.pricetop);filteram++;}
	if(filteram==0)printf("None");
	printf("\n");
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	printf("  | No. |            Book Name            |        Author        |    Genre    |     Publisher     | Year | Stock |   Price   |\n");
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	for(ctr=page*maxitemperpage; ctr<showbookamount&&ctr<(page+1)*maxitemperpage; ctr++){
		i=showbook[ctr];
		printf("  | %03d | %-31s | %-20s | %-11s | %-17s | %-4d |  %-4d | $%8.2f |\n", showbook[ctr]+1, booklist[i].name, booklist[i].auth, booklist[i].genre, booklist[i].pub, booklist[i].year, booklist[i].stock, booklist[i].price);
		disp++;
	}
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	printf("\t\t\t\t\t\t\t  [ %2d / %2d ]\t\t\t  Showing %4d out of %4d item(s).", page+1, maxpage+1, disp, bookamount);
}

void drawmenu(){
	printf("\n");
	printf("\tSelect an operation   :\n");
	printf("\t\t<. Go to previous page");
	printf("\t\t\t>. Go to next page\n");
	printf("\t\t1. Make a purchase");
	printf("\t\t\t2. Add a book entry\n");
	printf("\t\t3. Add or remove stock");
	printf("\t\t\t4. Sort books\n");
	printf("\t\t5. Add or remove filter");
	printf("\t\t\t6. Search books\n");
	printf("\t\t0. Exit and save database changes");
	printf("\t-. Exit and remove database changes\n");
	printf("\tOperation             : ");
}

void op2(){
	system("mode con: cols=65 lines=13");
	struct book newbook;
	char save, another='Y';
	while(lower(another)=='y'){
		system("cls");
		printf("\tAdd a book entry      :\n");
		printf("\tBook name             : ");scanf("%[^\n]", &newbook.name);getchar();
		printf("\tBook author           : ");scanf("%[^\n]", &newbook.auth);getchar();
		printf("\tBook genre            : ");scanf("%[^\n]", &newbook.genre);getchar();
		printf("\tBook publisher        : ");scanf("%[^\n]", &newbook.pub);getchar();
		printf("\tBook published year   : ");scanf("%hd", &newbook.year); getchar();
		printf("\tBook stock            : ");scanf("%hd", &newbook.stock); getchar();
		printf("\tBook price            : ");scanf("%f", &newbook.price); getchar();
		printf("\tAre you sure you want to save the book? ");scanf("%c", &save); getchar();
		if(lower(save)=='y')booklist[bookamount++]=newbook;
		printf("\tDo you want to add another book       ? ");scanf("%c", &another); getchar();
	}
	filterbooks();
	page=0;
	maxpage=(bookamount-1)/maxitemperpage;
}

void op5(){
	system("cls");
	system("mode con: cols=65 lines=13");
	int op, ctr;
	printf("\tFilters               :\n");
	printf("\t\t1. Turn %s name filter\n", filterlist.active[0]?"off":"on");
	printf("\t\t2. Turn %s author filter\n", filterlist.active[1]?"off":"on");
	printf("\t\t3. Turn %s genre filter\n", filterlist.active[2]?"off":"on");
	printf("\t\t4. Turn %s publisher filter\n", filterlist.active[3]?"off":"on");
	printf("\t\t5. Turn %s published year filter\n", filterlist.active[4]?"off":"on");
	printf("\t\t6. Turn %s stock filter\n", filterlist.active[5]?"off":"on");
	printf("\t\t7. Turn %s price filter\n", filterlist.active[6]?"off":"on");
	printf("\t\t8. Clear all filter off\n");
	printf("\t\t0. Cancel\n");
	printf("\tOperation             : ");
	scanf("%d", &op); getchar();
	if(!op)return;
	else if(op==8){for(ctr=0; ctr<7; ctr++)filterlist.active[ctr]=0;}
	else{
		filterlist.active[op-1]=!filterlist.active[op-1];
		if(filterlist.active[op-1]){
			if(op==1){
				printf("\tName Filter           : ");
				scanf("%[^\n]", &filterlist.name);getchar();
			}
			else if(op==2){
				printf("\tAuthor Filter         : ");
				scanf("%[^\n]", &filterlist.auth);getchar();
			}
			else if(op==3){
				printf("\tGenre Filter          : ");
				scanf("%[^\n]", &filterlist.genre);getchar();
			}
			else if(op==4){
				printf("\tPublisher Filter      : ");
				scanf("%[^\n]", &filterlist.pub);getchar();
			}
			else if(op==5){
				printf("\tYear Start Filter     : ");scanf("%hd", &filterlist.yearbot);
				printf("\tYear End   Filter     : ");scanf("%hd", &filterlist.yeartop);
				if(filterlist.yearbot<0)filterlist.yearbot*=-1;
				if(filterlist.yeartop<0)filterlist.yeartop*=-1;
				if(filterlist.yeartop<filterlist.yearbot){
					filterlist.yeartop+=filterlist.yearbot;
					filterlist.yearbot=filterlist.yeartop-filterlist.yearbot;
					filterlist.yeartop=filterlist.yeartop-filterlist.yearbot;
				}
			}
			else if(op==6){
				printf("\tStock Start Filter    : ");scanf("%hd", &filterlist.stockbot);
				printf("\tStock End   Filter    : ");scanf("%hd", &filterlist.stocktop);
				if(filterlist.stockbot<0)filterlist.stockbot*=-1;
				if(filterlist.stocktop<0)filterlist.stocktop*=-1;
				if(filterlist.stocktop<filterlist.stockbot){
					filterlist.stocktop+=filterlist.stockbot;
					filterlist.stockbot=filterlist.stocktop-filterlist.stockbot;
					filterlist.stocktop=filterlist.stocktop-filterlist.stockbot;
				}
			}
			else if(op==7){
				printf("\tPrice Start Filter    : ");scanf("%f", &filterlist.pricebot);
				printf("\tPrice End   Filter    : ");scanf("%f", &filterlist.pricetop);
				if(filterlist.pricebot<0)filterlist.pricebot*=-1;
				if(filterlist.pricetop<0)filterlist.pricetop*=-1;
				if(filterlist.pricetop<filterlist.pricebot){
					filterlist.pricetop+=filterlist.pricebot;
					filterlist.pricebot=filterlist.pricetop-filterlist.pricebot;
					filterlist.pricetop=filterlist.pricetop-filterlist.pricebot;
				}
			}
		}
	}
	filterbooks();
	page=0;
}

void op6(){
	
}

int main(){
	system("chcp 65001");
	system("title \"The Louvre Bookstore\"");
	char inputoperation[10];
	loaddata();
	while(1){
		system("mode con: cols=130 lines=50");
		system("cls");
		drawheader();
		drawcontent();
		drawmenu();
		scanf("%s", &inputoperation);getchar();
		if(inputoperation[0]=='0')break;
		else if(inputoperation[0]=='-')return 0;
		else if(inputoperation[0]=='<')page--;
		else if(inputoperation[0]=='>')page++;
		else if(inputoperation[0]=='1'){}
		else if(inputoperation[0]=='2')op2();
		else if(inputoperation[0]=='3'){}
		else if(inputoperation[0]=='4'){}
		else if(inputoperation[0]=='5')op5();
		else if(inputoperation[0]=='6')op6();
		if(page<0)page=maxpage;
		if(page>maxpage)page=0;
	}
	savedata();
}