#include<stdio.h>
#include<string.h>
#include<windows.h>

struct book{
	char name[100], auth[50], genre[30], pub[50];
	short year, stock;
	float price;
};

struct filter{
	int active[7];
	char name[100], auth[50], genre[30], pub[50];
	short yeartop, yearbot, stocktop, stockbot;
	float pricetop, pricebot;
};

struct book booklist[1000];
struct filter filterlist;
int bookammount=0;

void loaddata(){
	FILE *pfile;
	int ctr;
	pfile=fopen("booklist.txt", "r");
	for(ctr=0; 1; ctr++){
		if(fscanf(pfile, "%[^|]|%[^|]|%[^|]|%[^|]|%hd|%hd|%f\n", &booklist[ctr].name, &booklist[ctr].auth, &booklist[ctr].genre, &booklist[ctr].pub, &booklist[ctr].year, &booklist[ctr].stock, &booklist[ctr].price)==EOF)break;
		bookammount++;
	}
	fclose(pfile);
}

void savedata(){
	FILE *pfile;
	int ctr;
	pfile=fopen("booklist.txt", "w");
	for(ctr=0; ctr<bookammount; ctr++){
		fprintf(pfile, "%s|%s|%s|%s|%hd|%hd|%.2f\n", booklist[ctr].name, booklist[ctr].auth, booklist[ctr].genre, booklist[ctr].pub, booklist[ctr].year, booklist[ctr].stock, booklist[ctr].price);
	}
	fclose(pfile);
}

void drawheader(){
	printf("\n");
	printf("\t\t\t\t  ░░░ ░ ░ ░░░\n");
	printf("\t\t\t\t   ░  ░░░ ░░ \n");
	printf("\t\t\t\t   ░  ░ ░ ░░░\n");
	printf("\t\t\t\t▓▓    ▓▓▓▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓▓▓  ▓▓▓▓▓ ▒▒  ▒▒▒ ▒▒▒ ▒ ▒ ▒▒▒ ▒▒▒ ▒▒▒ ▒▒  ▒▒▒\n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓  ▓ ▓▓    ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒    ▒  ▒ ▒ ▒ ▒ ▒  \n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓▓▓  ▓▓▓▓▓ ▒▒  ▒ ▒ ▒ ▒ ▒▒  ▒▒▒  ▒  ▒ ▒ ▒▒  ▒▒▒\n");
	printf("\t\t\t\t▓▓    ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓ ▓▓    ▒ ▒ ▒ ▒ ▒ ▒ ▒ ▒   ▒  ▒  ▒ ▒ ▒ ▒ ▒  \n");
	printf("\t\t\t\t▓▓▓▓▓ ▓▓▓▓▓ ▓▓▓▓▓  ▓▓▓  ▓▓  ▓ ▓▓▓▓▓ ▒▒  ▒▒▒ ▒▒▒ ▒ ▒ ▒▒▒  ▒  ▒▒▒ ▒ ▒ ▒▒▒\n");
}

char lower(char x){return (x>='A'&&x<='Z')?x+32:x;}

int checkqualify(struct book test){
	int ctr1, ctr2;
	if(filterlist.active[0]){
		int namelen=strlen(test.name), filnamelen=strlen(filterlist.name), match;
		// printf("%d %d\n", namelen, filnamelen);
		for(ctr1=0; ctr1<namelen-filnamelen; ctr1++){
			match=0;
			for(ctr2=0; ctr2<filnamelen; ctr2++){
				if(lower(filterlist.name[ctr2])==lower(test.name[ctr1+ctr2])){
					// printf(".%c %c %d", lower(filterlist.name[ctr2]), lower(test.name[ctr1+ctr2]), match);
					match++;
				}
			}
			if(match==filnamelen)break;
		}
		if(match<filenamelen)return 0;
	}
	if(filterlist.active[1]){}
	if(filterlist.active[2]){}
	if(filterlist.active[3]){}
	if(filterlist.active[4]){}
	if(filterlist.active[5]){}
	if(filterlist.active[6]){}
	return 1;
}

void drawcontent(){
	int ctr;
	int filteram=0, disp=0;
	printf("\tActivated Filter: ");
	if(filterlist.active[0]){printf("Name (%s)", filterlist.name);filteram++;}
	if(filterlist.active[1]){printf("%sAuthor (%s)", filteram?", ":"", filterlist.auth);filteram++;}
	if(filterlist.active[2]){printf("%sGenre (%s)", filteram?", ":"", filterlist.genre);filteram++;}
	if(filterlist.active[3]){printf("%sPublisher (%s)", filteram?", ":"", filterlist.pub);filteram++;}
	if(filterlist.active[4]){printf("%sPublished Year (%hd-%hd)", filteram?", ":"", filterlist.yearbot, filterlist.yeartop);filteram++;}
	if(filterlist.active[5]){printf("%sStock (%hd-%hd)", filteram?", ":"", filterlist.stockbot, filterlist.stocktop);filteram++;}
	if(filterlist.active[6]){printf("%sPrice ($ %.2f-$ %.2f)", filteram?", ":"", filterlist.pricebot, filterlist.pricetop);filteram++;}
	if(filteram==0)printf("None");
	printf("\n");
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	printf("  | No. |            Book Name            |        Author        |    Genre    |     Publisher     | Year | Stock |   Price   |\n");
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	for(ctr=0; ctr<bookammount; ctr++){
		if(checkqualify(booklist[ctr])){
			printf("  | %03d | %-31s | %-20s | %-11s | %-17s | %-4d |  %-4d | $%8.2f |\n", ctr+1, booklist[ctr].name, booklist[ctr].auth, booklist[ctr].genre, booklist[ctr].pub, booklist[ctr].year, booklist[ctr].stock, booklist[ctr].price);
			disp++;
		}
	}
	printf("  +-----+---------------------------------+----------------------+-------------+-------------------+------+-------+-----------+\n");
	printf("\t\t\t\t\t\t\t\t\t\t\t\tShowing %d out of %d item(s).", disp, bookammount);
}

void drawmenu(){
	printf("\n");
	printf("\tStelect an operation  :\n");
	printf("\t\t1. Make a purchase\n");
	printf("\t\t2. Add a book entry\n");
	printf("\t\t3. Add or remove stock\n");
	printf("\t\t4. Sort books\n");
	printf("\t\t5. Add or remove filter\n");
	printf("\t\t6. Search books\n");
	printf("\t\t0. Exit and save database changes\n");
	printf("\t\t-. Exit and remove database changes\n");
	printf("\tOperation             : ");
}

void op5(){
	system("cls");
	system("mode con: cols=65 lines=15");
	int op;
	printf("\tFilters               :\n");
	printf("\t\t1. Turn %s name filter\n", filterlist.active[0]?"off":"on");
	printf("\t\t2. Turn %s author filter\n", filterlist.active[1]?"off":"on");
	printf("\t\t3. Turn %s genre filter\n", filterlist.active[2]?"off":"on");
	printf("\t\t4. Turn %s publisher filter\n", filterlist.active[3]?"off":"on");
	printf("\t\t5. Turn %s published year filter\n", filterlist.active[4]?"off":"on");
	printf("\t\t6. Turn %s stock filter\n", filterlist.active[5]?"off":"on");
	printf("\t\t7. Turn %s price filter\n", filterlist.active[6]?"off":"on");
	printf("\t\t0. Cancel\n");
	printf("\tOperation             : ");
	scanf("%d", &op); getchar();
	if(!op)return;
	filterlist.active[op-1]=!filterlist.active[op-1];
	if(filterlist.active[op-1]){
		if(op==1){
			printf("\tName Filter           : ");
			scanf("%[^\n]", &filterlist.name);getchar();
		}
		else if(op==2){}
		else if(op==3){}
		else if(op==4){}
		else if(op==5){}
		else if(op==6){}
		else if(op==7){}
	}
}

int main(){
	system("chcp 65001");
	system("title \"The Louvre Bookstore\"");
	int ctr, inputoperation;
	loaddata();
	while(1){
		system("mode con: cols=130 lines=50");
		system("cls");
		drawheader();
		drawcontent();
		drawmenu();
		scanf("%d", &inputoperation);
		if(inputoperation==0)break;
		else if(inputoperation<0)return 0;
		else if(inputoperation==1){}
		else if(inputoperation==2){}
		else if(inputoperation==3){}
		else if(inputoperation==4){}
		else if(inputoperation==5)op5();
		else if(inputoperation==6){}
	}
	savedata();
}